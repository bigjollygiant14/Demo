var app = angular.module('MyFriendSearchApp',[]);
var inlineEdit = angular.module('InlineEditor',[]);