var map, infowindow, dentistMarker; //define these as global variables so they can be accessed from the showDentistInfowindow() function

function createMap() {

//define a coordinate to use as the map center, this would be the center of your map except later on in the code the infowindow is opened which pans the map to fit the infowindow
var mapCenter = new google.maps.LatLng(38.969553,-77.209424);

//these first three options are required, I also like to disable the pan control because nobody needs that shit when you can just drag the map, see here for all the options https://developers.google.com/maps/documentation/javascript/maps_for_business_reference#MapOptions
var mapOptions = {
  zoom: 11,
  center: mapCenter,
  mapTypeId: google.maps.MapTypeId.ROADMAP,
  panControl: false
}

//get the div where you want to place the map
var mapDomElement = document.getElementById('mapContainer');

//create the map object, this immediately fills your mapContainer div with the map, it appears on the page and the user can interact with it
map = new google.maps.Map(mapDomElement, mapOptions);

//create an HTML string to use as the contents of the infowindow
var dentistDescription = '<div id="dentistInfowindow">'+
'<h3>Dr. Jay&#39;s Office</h3>'+
'<p>8230 Leesburg Pike</p>'+
'<p>Suite 730</p>'+
'<p>Vienna, Virginia 22182</p>'+
'<p>Phone (703) 893-5250</p>'+
'<p><a target="_blank" href="'+
'https://maps.google.com/maps?saddr=&daddr=8230%20Leesburg%20Pike%20Vienna%20VA'+
'">'+
'Get Directions'+
'</a>'+
'</div>';

//create an infowindow overlay, set it's contents to the HTML string to appear inside, don't add it to the map yet
infowindow = new google.maps.InfoWindow({
  content: dentistDescription
});

//define a coordinate to use as the position of the marker.  Make this South of the map center so when the infowindow is opened its top is not cutoff
var dentistCoordinates = new google.maps.LatLng(38.918121,-77.229424);
var image = {
  url: ''
}
//create the map marker and add it to the map
dentistMarker = new google.maps.Marker({
  position: dentistCoordinates,
    map: map, //setting the markers "map" option to the Google Maps object adds the marker to the map, this is weird, I know
    title: 'The Dentist' //this appears in a tooltip when the mouse cursor hovers over the map marker
    //icon: image //optional path to custom icon
  });

//add an event listener to the marker, fired by a 'click', which calls the showDentistInfowindow() function
google.maps.event.addListener(dentistMarker, 'click', showDentistInfowindow);

//open the infowindow immediately
showDentistInfowindow();
}

function showDentistInfowindow(){
//open the infowindow on the map, attached to your dentist marker
infowindow.open(map,dentistMarker);
}

/* http://www.willjallday.com/skunkworks/pages/directions.html
take their address
https://maps.google.com/maps?saddr={THEIR ADDRESS}&daddr={YOUR ADDRESS}
google takse address
https://maps.google.com/maps?saddr=&daddr=8230%20Leesburg%20Pike%20Vienna%20VA*/
//GETS DIRECTIONS
function calcRoute() {
//DIRECTION VARIABLES
var start = document.getElementById("start").value;
var end = officeLocationLat + ", " + officeLocationLong;
var request = {
  origin:start,
  destination:end,
  travelMode: google.maps.DirectionsTravelMode.DRIVING
};
//GETS DIRECTIONS FROM GOOGLE
directionsService.route(request, function(response, status) {
  if (status == google.maps.DirectionsStatus.OK) {
   directionsDisplay.setDirections(response);
 }
});
}
